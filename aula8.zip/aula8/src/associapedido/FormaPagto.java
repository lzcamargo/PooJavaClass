package associapedido;

public enum FormaPagto {
	CHEQUE,
	CARTÃO,
	DINHEIRO
}
