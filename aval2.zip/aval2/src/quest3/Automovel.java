package quest3;

public class Automovel extends Veiculo {
	private float litrosOleo;
	
	public void trocarOleo(float litros) {
		this.litrosOleo = litros;
	}

}
