package quest3;

public class Bicicleta extends Veiculo {

}
