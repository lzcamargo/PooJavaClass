package n2;

public interface ImpostoProduto {
	void calcImpostoProduto();

}
