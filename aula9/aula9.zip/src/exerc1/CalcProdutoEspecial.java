package exerc1;

public interface CalcProdutoEspecial {
	public float calcularPrecoEspecial();
}
