package exerc1;

public interface CalcProdutoNEspecial {
	public float calcularPrecoNEspecial();

}
