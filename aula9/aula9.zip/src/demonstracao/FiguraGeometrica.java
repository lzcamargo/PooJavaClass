package demonstracao;

public interface FiguraGeometrica {
	
	public static float PI = 3.14159f;
	public void nomeFigura();
	public void calcularArea();
	public void calcularPerimetro();

}
