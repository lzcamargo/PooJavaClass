package demonstracao;

public interface Motor {
	public String getModelo();
  public String getFabricante();

}
