package demonstracao;

public interface Streaming {
	public void iniciar();
  public void pausar();
  public void parar();
}
