package demonstracao;

public class SmartPhone implements ReproduzStreaming {

	@Override
	public void iniciar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pausar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void parar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void proxima() {
		// TODO Auto-generated method stub
		ReproduzStreaming.super.proxima();
	}

		
}
