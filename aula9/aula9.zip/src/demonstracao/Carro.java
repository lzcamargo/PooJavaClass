package demonstracao;

public class Carro implements Veiculo, Motor {

	@Override
	public String getModelo() {
		return null;
	}

	@Override
	public String getFabricante() {
		return null;
	}

	@Override
	public String getNome() {
		return null;
	}

	@Override
	public String getId() {
		return null;
	}
	

}
