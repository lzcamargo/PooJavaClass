package demonstracao;

public interface Veiculo {
	public String getNome();
  public String getId();

}
