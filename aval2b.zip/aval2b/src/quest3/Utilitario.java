package quest3;

public class Utilitario extends Automovel {
	private float capacidadeCarga;
	
	public void  carregarUtilitario(float capacidadeCarga) {
		this.capacidadeCarga = capacidadeCarga;
	}

	public float getCapacidadeCarga() {
		return capacidadeCarga;
	}

	public void setCapacidadeCarga(float capacidadeCarga) {
		this.capacidadeCarga = capacidadeCarga;
	}
	
	

}
