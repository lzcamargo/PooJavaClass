package quest3;

public class Passeio extends Automovel {

}
